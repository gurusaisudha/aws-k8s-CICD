my k8s deployment files
